def hello():
    print("HelloWorld")
